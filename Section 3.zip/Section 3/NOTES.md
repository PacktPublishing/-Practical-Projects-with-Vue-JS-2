php artisan storage:link

composer require pusher/pusher-php-server
